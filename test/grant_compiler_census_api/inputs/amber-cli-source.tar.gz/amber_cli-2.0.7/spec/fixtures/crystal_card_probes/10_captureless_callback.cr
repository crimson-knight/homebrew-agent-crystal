callback = -> { true }
callback.call
