require "json"
require "yaml"
require "uri"

require "./amber_lsp/version"
require "./amber_lsp/rules/severity"
require "./amber_lsp/rules/diagnostic"
require "./amber_lsp/rules/base_rule"
require "./amber_lsp/rules/rule_registry"
require "./amber_lsp/rules/controllers/*"
require "./amber_lsp/rules/jobs/*"
require "./amber_lsp/rules/channels/*"
require "./amber_lsp/rules/pipes/*"
require "./amber_lsp/rules/mailers/*"
require "./amber_lsp/rules/schemas/*"
require "./amber_lsp/rules/file_naming/*"
require "./amber_lsp/rules/routing/*"
require "./amber_lsp/rules/specs/*"
require "./amber_lsp/rules/sockets/*"
require "./amber_lsp/rules/fsdd/*"
require "./amber_lsp/rules/custom_rule"
require "./amber_lsp/document_store"
require "./amber_lsp/project_context"
require "./amber_lsp/configuration"
require "./amber_lsp/library_rule_packs/describe_library_rule_pack"
require "./amber_lsp/library_rule_packs/load_rule_packs_for_project"
require "./amber_lsp/library_rule_packs/visit_crystal_calls_outside_required_blocks"
require "./amber_lsp/library_rule_packs/grant_tenancy/source_node"
require "./amber_lsp/library_rule_packs/grant_tenancy/grant_tenant_model_declaration"
require "./amber_lsp/library_rule_packs/grant_tenancy/collect_project_grant_tenancy_declarations"
require "./amber_lsp/library_rule_packs/determine_project_rule_pack_state"
require "./amber_lsp/library_rule_packs/grant_tenancy/visit_chainable_unscoped_model_calls"
require "./amber_lsp/library_rule_packs/grant_tenancy/visit_spawn_calls_inside_grant_tenant_blocks"
require "./amber_lsp/library_rule_packs/grant_tenancy/visit_grant_tenant_clear_calls"
require "./amber_lsp/library_rule_packs/grant_tenancy/visit_raw_connection_sql_call_sites"
require "./amber_lsp/library_rule_packs/grant_tenancy/visit_grant_schema_queries_outside_tenant_blocks"
require "./amber_lsp/library_rule_packs/analyze_project_files_with_rule_packs"
require "./amber_lsp/library_rule_packs/print_detected_rule_pack_contexts"
require "./amber_lsp/analyzer"
require "./amber_lsp/analyze_file_with_coverage"
require "./amber_lsp/controller"
require "./amber_lsp/server"
require "./amber_lsp/check_file_for_diagnostics"
require "./amber_lsp/lookup/build_layered_api_index"
require "./amber_lsp/lookup/resolve_api_query"
require "./amber_lsp/lookup/answer_api_query"
require "./amber_lsp/lookup/verify_api_query"
require "./amber_lsp/lookup/lookup_command"
require "./amber_lsp/lookup/hint_command"

if ARGV.first?.in?("--help", "-h", "help")
  STDOUT.puts AmberLSP::USAGE
  exit 0
elsif ARGV.includes?("--version")
  STDOUT.puts AmberLSP.version_line
  exit 0
elsif ARGV.first? == "lookup"
  exit AmberLSP::Lookup::RunLookupCommand.new(ARGV[1..].to_a).perform
elsif ARGV.first? == "hint"
  exit AmberLSP::Lookup::RunHintCommand.new(ARGV[1..].to_a).perform
elsif ARGV[0]? == "--check"
  file_path = ARGV[1]?
  unless file_path
    STDERR.puts "Usage: amber-lsp --check FILE.cr"
    exit 2
  end
  exit AmberLSP::CheckFileForDiagnostics.new(file_path).perform
elsif ARGV.first? == "context"
  exit AmberLSP::LibraryRulePacks::PrintDetectedRulePackContexts.new(ARGV[1..].to_a).perform
else
  AmberLSP::Server.new(STDIN, STDOUT).run
end
