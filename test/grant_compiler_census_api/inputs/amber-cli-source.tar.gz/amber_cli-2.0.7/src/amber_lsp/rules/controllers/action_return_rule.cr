module AmberLSP::Rules::Controllers
  class ActionReturnRule < AmberLSP::Rules::BaseRule
    RESPONSE_METHODS   = ["render", "redirect_to", "redirect_back", "respond_with", "halt!"]
    SKIPPED_METHODS    = ["initialize", "before_action", "after_action", "before_filter", "after_filter"]
    VISIBILITY_CHANGE  = /^\s*(private|protected|public)\s*$/
    METHOD_DECLARATION = /^(\s{2,4})(?:(private|protected|public)\s+)?def\s+([\w!?]+)/
    CLASS_METHOD       = /^\s{2,4}(?:(?:private|protected|public)\s+)?def\s+self\./
    CLASS_DECLARATION  = /^(\s*)class\b/
    END_DECLARATION    = /^(\s*)end\b/

    def id : String
      "amber/action-return-type"
    end

    def description : String
      "Public controller actions should call render, redirect_to, redirect_back, respond_with, or halt!"
    end

    def default_severity : AmberLSP::Rules::Severity
      Severity::Warning
    end

    def applies_to : Array(String)
      ["src/controllers/*"]
    end

    def check(file_path : String, content : String) : Array(Diagnostic)
      return [] of Diagnostic unless file_path.includes?("controllers/")
      return [] of Diagnostic if action_support_file?(file_path)

      diagnostics = [] of Diagnostic
      lines = content.lines

      in_public_method = false
      method_name = ""
      method_line = 0
      method_start_char = 0
      method_end_char = 0
      method_indent = 0
      has_response_call = false
      is_private_section = false
      list_of_class_indents = [] of Int32

      lines.each_with_index do |line, line_number|
        if class_match = CLASS_DECLARATION.match(line)
          list_of_class_indents << class_match[1].size
          is_private_section = false
        end

        # Track visibility section changes
        if visibility_match = VISIBILITY_CHANGE.match(line)
          is_private_section = visibility_match[1] != "public"
          next
        end

        if end_match = END_DECLARATION.match(line)
          if list_of_class_indents.last? == end_match[1].size
            list_of_class_indents.pop
            is_private_section = false
          end
        end

        # Detect method start at standard 2-space indent (methods inside a class)
        method_match = METHOD_DECLARATION.match(line)
        if method_match && !in_public_method
          next if CLASS_METHOD.matches?(line)

          indent = method_match[1].size
          visibility = method_match[2]?
          name = method_match[3]

          # Skip private/protected methods and special methods
          is_private_section = false if visibility == "public"
          next if visibility == "private" || visibility == "protected"
          next if is_private_section
          next if SKIPPED_METHODS.includes?(name)

          in_public_method = true
          method_name = name
          method_line = line_number
          method_start_char = (method_match.begin(3) || 0).to_i32
          method_end_char = (method_match.end(3) || line.size).to_i32
          method_indent = indent
          has_response_call = false
          next
        end

        if in_public_method
          # Check for response method calls
          if response_written_or_returned?(line)
            has_response_call = true
          end

          # Detect method end at same or lesser indent level
          end_match = /^(\s*)end\b/.match(line)
          if end_match
            end_indent = end_match[1].size
            if end_indent <= method_indent
              unless has_response_call
                diagnostics << Diagnostic.new(
                  range: TextRange.new(
                    Position.new(method_line.to_i32, method_start_char),
                    Position.new(method_line.to_i32, method_end_char)
                  ),
                  severity: default_severity,
                  code: id,
                  message: "Action '#{method_name}' does not appear to call render, redirect_to, redirect_back, respond_with, or halt!"
                )
              end
              in_public_method = false
            end
          end
        end
      end

      diagnostics
    end

    private def action_support_file?(file_path : String) : Bool
      File.basename(file_path) == "application_controller.cr" ||
        file_path.includes?("controllers/concerns/")
    end

    private def response_written_or_returned?(line : String) : Bool
      RESPONSE_METHODS.any? { |method_name| line.includes?(method_name) } ||
        line.includes?("respond_") ||
        line.matches?(/\bcontext\.response\.(print|write)\b/) ||
        line.matches?(/\b\w+\(context\.response\b/) ||
        line.includes?("String.build")
    end
  end
end

AmberLSP::Rules::RuleRegistry.register(AmberLSP::Rules::Controllers::ActionReturnRule.new)
