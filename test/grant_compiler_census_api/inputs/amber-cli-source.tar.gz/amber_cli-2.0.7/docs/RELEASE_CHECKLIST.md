# Amber V2 Beta Release Checklist

Release order matters because generated apps pin a framework version and the
Homebrew formula pins Amber and Minecart source archives and checksums.

## 1. Framework prerequisite

1. Confirm the published `v2.0.0-beta.5` prerelease has its source archive and
   checksum and matches the generated app's exact framework pin.
2. Check the framework's migration and support-matrix links.

## 2. CLI release

1. Confirm `shard.yml` and `AmberCLI::VERSION` both say `2.0.7`.
2. Generate a web app and verify it pins the framework prerelease.
3. Verify the generated app pins the reviewed Asset Pipeline release exactly,
   has a Minecart Git tree checksum for every dependency, and has assistant
   files.
4. On macOS, x86-64 Linux, and ARM64 Linux, run `minecart install --frozen --skip-ai-docs`; run
   `amber assets build` and `amber assets check`; run app specs; build and start
   the app; then follow the manifest-rendered CSS, JavaScript, SVG, and favicon
   URLs from `/`.
5. For fingerprinted responses, verify MIME, SRI in rendered tags, immutable
   caching, `nosniff`, and gzip negotiation. Confirm CSS rewrites its authored
   image URL and that `public/assets/` contains no source-owned raw entry point.
6. On macOS, reject any binary linked to `openssl@1.1`.
7. Confirm the Windows x86-64 generated app passes its full CI smoke, including
   launch and asset probes. This is a generated-app release gate, with no
   Windows archive yet.
8. Tag `v2.0.7`, publish the release, and wait for the binary and source
   archives and checksum files to upload. Compare the published source archive
   hash with the reviewed Homebrew formula before pushing the tap.

## 3. Homebrew

1. Update the underscore tap, `amberframework/homebrew-amber_cli`.
2. Verify both source archive checksums in the formula.
3. Run `brew trust --tap amberframework/amber_cli`, pin the reviewed tap commit,
   then run `HOMEBREW_NO_AUTO_UPDATE=1 brew install
   amberframework/amber_cli/amber_cli` on macOS and Linux.
4. Repeat the complete generated-web-app smoke test from the installed formula.

## 4. Documentation

1. Publish framework, CLI, and website guides with the same command names,
   versions, platform matrix, and preview labels.
2. Check that no onboarding page uses a hyphenated tap or formula name, a
   tap without trust and a commit pin, a personal Amber fork, a moving `v2-dev` dependency, or
   Slang for a new V2 app.
3. Verify all release/download links and commands from a clean shell.

Do not mark the beta complete if macOS, x86-64 Linux, or ARM64 Linux cannot
install the CLI and complete the generated web-app and asset smoke. Record a
Windows CI failure as a failed generated-app release gate; Windows packaging
remains a separate open item.
