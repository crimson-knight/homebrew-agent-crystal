---
name: "\U0001F680 Feature Request"
about: I want to propose a new language feature.
labels: kind:feature
type: Feature
---

# Feature Request

- Is your feature request related to a problem? Please describe clearly and concisely what is it.
- Describe the feature you would like, optionally illustrated by examples, and how it will solve the above problem.
- Describe considered alternative solutions, and the reasons why you have not proposed them as a solution here.
- Does it break backward compatibility, if yes then what's the migration path?

In case this proposal includes a substantial change to the language, we ask you to go through an [RFC process](https://github.com/crystal-lang/rfcs).

The best place to start an open discussion about potential changes is the [Crystal forum](https://forum.crystal-lang.org/c/crystal-contrib/6).

---

Add a :+1: [reaction] to [issues you find important].

[reaction]: https://github.blog/2016-03-10-add-reactions-to-pull-requests-issues-and-comments/
[issues you find important]: https://github.com/crystal-lang/crystal/issues?q=is%3Aissue+is%3Aopen+sort%3Areactions-%2B1-desc
