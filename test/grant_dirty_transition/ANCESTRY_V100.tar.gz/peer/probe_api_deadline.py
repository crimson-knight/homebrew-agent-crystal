"""Retain an actual Runner refusal through a guarded unknown-card retry."""
from contextlib import ExitStack
from pathlib import Path
from unittest import mock
import argparse
import hashlib
import importlib.util
import json
import sys
import tempfile
from types import SimpleNamespace

HERE = Path(__file__).resolve().parent
PACKET = HERE.parent / 'grant_dirty_transition_v100'
parser = argparse.ArgumentParser()
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()


def need(value, message):
    if not value:
        raise ValueError(message)


pins = json.loads((PACKET / 'SOURCE_PINS.json').read_bytes())
need(hashlib.sha256((PACKET / 'SOURCE_PINS.json').read_bytes()).hexdigest() == 'a6912de7dbe3cf6186c755db7fde74dd72ddd6ce53f0d42676df2ba3bf76149b', 'Exact frozen Grant packet')
for row in pins['files']:
    path = PACKET / row['path']
    need(path.stat().st_size == row['bytes'] and hashlib.sha256(path.read_bytes()).hexdigest() == row['sha256'], 'Frozen source closure')
sys.path.insert(0, str(PACKET))
sys.path.insert(0, str(PACKET / 'vendor'))
calls = []


def guarded(*args, **kwargs):
    calls.append('external entrypoint')
    raise AssertionError('Source and mocked process fixture scope')


with ExitStack() as guards:
    for name in ['subprocess.Popen', 'os.system', 'os.fork', 'os.posix_spawn', 'os.posix_spawnp', 'os.kill', 'os.killpg']:
        guards.enter_context(mock.patch(name, side_effect=guarded))
    import dirty_proof as proof
    driver_path = PACKET / 'vendor/sdk_install_qualification.py'
    need(hashlib.sha256(driver_path.read_bytes()).hexdigest() == proof.DRIVER_SHA256, 'Exact actual proof Runner source')
    spec = importlib.util.spec_from_file_location('probe_actual_original_runner', driver_path)
    driver = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(driver)
    with tempfile.TemporaryDirectory(prefix='guarded API deadline with spaces ') as name:
        output = Path(name).resolve()
        method = 'Hash#delete'
        found = dict(query=method, status='found', api_card_errors=[], freshness='fresh',
                     entries=[{'signature': 'delete(key)'}], failure_reason=None, verification_status='present')
        unknown = dict(found, status='unknown', entries=[], verification_status=None)
        clock = SimpleNamespace(value=0.0)
        mocked_processes = []

        class Process:
            def __init__(self, argv, **options):
                self.index = len(mocked_processes)
                mocked_processes.append(list(argv))
                self.pid = 8100 + self.index
                self.code = 4 if self.index == 0 else 0
                options['stdout'].write(json.dumps(unknown if self.index == 0 else found).encode())
                options['stdout'].flush()
                clock.value = 11.0 if self.index == 0 else 12.0

            def poll(self):
                return self.code

            def wait(self, timeout):
                return self.code

        with mock.patch.object(driver.time, 'monotonic', side_effect=lambda: clock.value), \
                mock.patch.object(driver.subprocess, 'Popen', side_effect=Process), \
                mock.patch.object(driver.Runner, 'observe_group', return_value={'status': 'absent'}):
            runner = driver.Runner(output)
            runner.deadline = 100.0
            returned = proof.lookup(runner, '/mocked/amber-lsp', method, 0, output, {}, output)
            need(returned == found and len(runner.records) == 2, 'Unknown-card retry completed')
            first = runner.records[0]
            need(first['exit_code'] == 4 and first['maximum_seconds'] == 10 and first['elapsed_seconds'] == 11 and
                 first['refusal'] == 'Command exceeded its time budget', 'Actual original Runner emitted a genuine modeled deadline refusal')
            value = dict(passed=True, finalization_errors=[], elapsed_seconds=12,
                         commands=runner.records, groups=runner.group_observations,
                         writers_confirmed_retired=True, overlays=[{'restored': True} for _ in range(4)])
            accepted_return = True
            try:
                proof.complete_return(value, output)
            except RuntimeError:
                accepted_return = False
            result = {'actual_original_Runner_source_sha256': proof.DRIVER_SHA256,
                      'original_lookup_record': first, 'verification_record': runner.records[1],
                      'lookup_accepted_despite_original_deadline_refusal': returned == found,
                      'complete_return_accepted_deadline_refused_command': accepted_return,
                      'mocked_process_observations': len(mocked_processes), 'actual_external_guard_calls': len(calls),
                      'actual_local_compiler_native_container_ssh_workload_jobs': 0,
                      'scope': 'Actual reviewed Runner and proof reader; process/version/API bytes and clock are mocked metadata fixtures'}
            args.output.write_text(json.dumps(result, indent=2) + '\n')
            print(json.dumps({'lookup_accepted': True, 'first_elapsed': first['elapsed_seconds'],
                              'first_maximum': first['maximum_seconds'], 'first_refusal': first['refusal'],
                              'complete_return_accepted': accepted_return, 'external_guard_calls': len(calls)}))
