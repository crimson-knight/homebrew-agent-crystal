require "../spec_helper"

module Ameba::Rule
  root = Path[__DIR__, "..", ".."].expand

  describe Base do
    context ".rules" do
      it "returns a list of all rules" do
        rules = Rule.rules
        rules.should_not be_nil
        rules.should contain DummyRule
      end

      it "contains rules across all the available groups" do
        Rule.rules.map(&.group_name).uniq!.reject!(&.empty?).sort.should eq %w[
          Ameba
          Documentation
          Layout
          Lint
          Metrics
          Naming
          Performance
          Style
          Typing
        ]
      end
    end

    context "properties" do
      subject = DummyRule.new

      it "is enabled by default" do
        subject.enabled?.should be_true
      end

      it "has a description property" do
        subject.description.should_not be_nil
      end

      it "has a dummy? property" do
        subject.dummy?.should be_true
      end

      it "has excluded property" do
        subject.excluded.should be_nil
      end
    end

    describe "#excluded?" do
      it "returns false if a rule does no have a list of excluded source" do
        DummyRule.new.excluded?(Source.new(path: "source.cr")).should_not be_true
      end

      it "returns false if source is not excluded from this rule" do
        rule = DummyRule.new
        rule.excluded = Set{"some_source.cr"}
        rule.excluded?(Source.new(path: "another_source.cr")).should_not be_true
      end

      it "returns true if source is excluded from this rule" do
        rule = DummyRule.new
        rule.excluded = Set{"source.cr"}
        rule.excluded?(Source.new(path: "source.cr")).should be_true
      end

      it "returns true if source matches the wildcard" do
        rule = DummyRule.new
        rule.excluded = Set{"**/*.cr"}
        rule.excluded?(Source.new(path: __FILE__), root).should be_true
      end

      it "returns false if source does not match the wildcard" do
        rule = DummyRule.new
        rule.excluded = Set{"*_spec.cr"}
        rule.excluded?(Source.new(path: "source.cr")).should be_false
      end
    end

    describe ".documentation_url" do
      it "returns the parsed rule documentation URL" do
        Lint::Syntax.documentation_url.should eq \
          "https://crystal-ameba.org/api/master/Ameba/Rule/Lint/Syntax.html"
      end
    end

    describe ".parsed_doc" do
      it "returns the parsed rule doc" do
        DummyRule.parsed_doc.should eq "Dummy Rule which does nothing."
      end
    end

    describe "#==" do
      it "returns true if rule has the same name" do
        DummyRule.new.should eq(DummyRule.new)
      end

      it "returns false if rule has a different name" do
        DummyRule.new.should_not eq(ScopeRule.new)
      end
    end
  end
end
