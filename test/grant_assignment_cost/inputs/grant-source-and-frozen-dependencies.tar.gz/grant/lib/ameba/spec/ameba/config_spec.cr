require "../spec_helper"

private AMEBA_ROOT =
  Path[__DIR__, "..", ".."].expand

private CONFIG_SAMPLE =
  Path[__DIR__, "..", "fixtures", ".ameba.yml"].to_s

private def load_config(path = CONFIG_SAMPLE, *args, **kwargs)
  Ameba::Config.load(path, *args, **kwargs)
end

module Ameba
  describe Config do
    it "should have a list of available formatters" do
      Config::AVAILABLE_FORMATTERS.should_not be_nil
    end

    describe ".new" do
      it "raises when the config is not a Hash" do
        yaml = YAML.parse("[]")
        expect_raises(Exception, "Invalid config file format") do
          Config.from_yaml(yaml)
        end
      end

      it "loads default globs when config is empty" do
        yaml = YAML.parse("{}")
        config = Config.from_yaml(yaml)
        config.globs.should eq Config::DEFAULT_GLOBS
      end

      it "loads default globs when config has no value" do
        yaml = YAML.parse <<-YAML
          # Empty config with comment
          YAML
        config = Config.from_yaml(yaml)
        config.globs.should eq Config::DEFAULT_GLOBS
      end

      it "initializes globs as string" do
        yaml = YAML.parse <<-YAML
          ---
          Globs: src/*.cr
          YAML
        config = Config.from_yaml(yaml)
        config.globs.should eq Set{"src/*.cr"}
      end

      it "initializes globs as array" do
        yaml = YAML.parse <<-YAML
          ---
          Globs:
            - "src/*.cr"
            - "!spec"
          YAML
        config = Config.from_yaml(yaml)
        config.globs.should eq Set{"src/*.cr", "!spec"}
      end

      it "raises if Globs has a wrong type" do
        yaml = YAML.parse <<-YAML
          ---
          Globs: 100
          YAML
        expect_raises(Exception, "Incorrect `Globs` section in a config file") do
          Config.from_yaml(yaml)
        end
      end

      it "initializes excluded as string" do
        yaml = YAML.parse <<-YAML
          ---
          Excluded: spec
          YAML
        config = Config.from_yaml(yaml)
        config.excluded.should eq Set{"spec"}
      end

      it "initializes excluded as array" do
        yaml = YAML.parse <<-YAML
          ---
          Excluded:
            - spec
            - lib/*.cr
          YAML
        config = Config.from_yaml(yaml)
        config.excluded.should eq Set{"spec", "lib/*.cr"}
      end

      it "raises if Excluded has a wrong type" do
        yaml = YAML.parse <<-YAML
          ---
          Excluded: true
          YAML
        expect_raises(Exception, "Incorrect `Excluded` section in a config file") do
          Config.from_yaml(yaml)
        end
      end
    end

    describe ".load" do
      it "loads custom config" do
        config = load_config
        config.should_not be_nil
        config.version.should_not be_nil
        config.globs.should_not be_nil
        config.formatter.should be_a Formatter::FlycheckFormatter
      end

      it "raises when custom config file doesn't exist" do
        expect_raises(Exception, %(Unable to load config file: Config file "foo.yml" does not exist)) do
          Config.load("foo.yml")
        end
      end

      it "loads default config" do
        config = load_config(skip_reading_config: true)
        config.version.should be_nil
        config.globs.should_not be_nil
        config.formatter.should_not be_nil
      end
    end

    describe "#globs, #globs=" do
      it "holds source globs" do
        config = load_config
        config.globs.should eq Config::DEFAULT_GLOBS
      end

      it "allows to set globs" do
        config = load_config
        config.globs = Set{"src/**/*.cr"}
        config.globs.should eq Set{"src/**/*.cr"}
      end
    end

    describe "#excluded, #excluded=" do
      it "defaults to `lib`" do
        config = load_config
        config.excluded.should eq Set{"lib"}
      end

      it "allows to set excluded" do
        config = load_config
        config.excluded = Set{"spec"}
        config.excluded.should eq Set{"spec"}
      end
    end

    describe "#sources" do
      config = load_config(root: AMEBA_ROOT)

      after_each do
        config = load_config(root: AMEBA_ROOT)
      end

      it "returns list of sources" do
        config.sources.size.should be > 0
        config.sources.first.should be_a Source
        config.sources.any?(&.fullpath.==(__FILE__)).should be_true
      end

      it "returns a list of sources matching globs" do
        config.globs = Set{"**/config_spec.cr"}
        config.sources.size.should eq(1)
      end

      it "returns a list of sources excluding 'Excluded'" do
        config.excluded = Set{"**/config_spec.cr"}
        config.sources.any?(&.fullpath.==(__FILE__)).should be_false
      end
    end

    describe "#formatter, formatter=" do
      formatter = DummyFormatter.new
      config = load_config

      after_each do
        config = load_config
      end

      it "contains default formatter" do
        config.formatter.should_not be_nil
      end

      it "allows to set formatter" do
        config.formatter = formatter
        config.formatter.should eq formatter
      end

      it "allows to set formatter using a name" do
        config.formatter = :progress
        config.formatter.should_not be_nil
      end

      it "raises an error if not available formatter is set" do
        expect_raises(Exception) do
          config.formatter = :no_such_formatter
        end
      end
    end

    describe "#version, version=" do
      version = SemanticVersion.parse("1.5.0")
      config = load_config

      after_each do
        config = load_config
      end

      it "contains default version" do
        config.version.should_not be_nil
      end

      it "allows to set version" do
        config.version = version
        config.version.should eq version
      end

      it "allows to set version using a string" do
        config.version = version.to_s
        config.version.should eq version
      end

      it "raises an error if version is not valid" do
        expect_raises(Exception) do
          config.version = "foo"
        end
      end
    end

    describe "#update_rule" do
      config = load_config

      after_each do
        config = load_config
      end

      it "updates enabled property" do
        name = DummyRule.rule_name
        rule = config.rules.find!(&.name.== name)
        rule.excluded = excluded = Set{"spec/source.cr"}

        config.update_rule(name, enabled: false)
        rule.enabled?.should be_false
        rule.excluded.should eq excluded
      end

      it "updates excluded property" do
        name = DummyRule.rule_name
        excluded = Set{"spec/source.cr"}
        config.update_rule(name, enabled: true, excluded: excluded)
        rule = config.rules.find!(&.name.== name)
        rule.excluded.should eq excluded
      end
    end

    describe "#update_rules" do
      config = load_config

      after_each do
        config = load_config
      end

      it "updates multiple rules by enabled property" do
        name = DummyRule.rule_name
        rule = config.rules.find!(&.name.== name)
        rule.excluded = excluded = Set{"spec/source.cr"}

        config.update_rules([name], enabled: false)
        rule.enabled?.should be_false
        rule.excluded.should eq excluded
      end

      it "updates multiple rules by excluded property" do
        name = DummyRule.rule_name
        excluded = Set{"spec/source.cr"}
        config.update_rules([name], enabled: true, excluded: excluded)
        rule = config.rules.find!(&.name.== name)
        rule.excluded.should eq excluded
      end

      it "updates a group of rules by enabled property" do
        group = DummyRule.group_name
        config.update_rules([group], enabled: false)
        rule = config.rules.find!(&.name.== DummyRule.rule_name)
        rule.enabled?.should be_false
      end

      it "updates a group by excluded property" do
        name = DummyRule.group_name
        excluded = Set{"spec/source.cr"}
        config.update_rules([name], enabled: true, excluded: excluded)
        rule = config.rules.find!(&.name.== DummyRule.rule_name)
        rule.excluded.should eq excluded
      end
    end
  end
end
