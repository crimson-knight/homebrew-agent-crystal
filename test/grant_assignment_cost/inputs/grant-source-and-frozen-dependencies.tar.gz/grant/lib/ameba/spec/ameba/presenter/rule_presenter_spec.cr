require "../../spec_helper"

module Ameba
  private def rule_presenter_each_rule(&)
    rules = Config.load(skip_reading_config: true).rules

    rules.each do |rule|
      with_presenter(Presenter::RulePresenter, rule) do |presenter, output|
        yield rule, output, presenter
      end
    end
  end

  describe Presenter::RulePresenter do
    it "outputs rule details" do
      rule_presenter_each_rule do |rule, output|
        output.should contain rule.name
        output.should contain rule.severity.to_s
        output.should contain rule.class.documentation_url

        if description = rule.description
          output.should contain description
        end
      end
    end
  end
end
